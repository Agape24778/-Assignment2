package com.example.maindart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
